"use client"

import KinasConsulting from "../kinas-consulting-website"

export default function SyntheticV0PageForDeployment() {
  return <KinasConsulting />
}